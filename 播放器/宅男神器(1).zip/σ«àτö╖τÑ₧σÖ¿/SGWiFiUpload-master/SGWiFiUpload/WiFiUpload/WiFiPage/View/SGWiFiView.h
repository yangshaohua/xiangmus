//
//  SGWiFiView.h
//  SGWiFiUpload
//
//  Created by soulghost on 30/6/2016.
//  Copyright © 2016 soulghost. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SGWiFiView : UIView

- (void)setAddress:(NSString *)address;

@end
