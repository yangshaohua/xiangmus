//
//  SGConst.m
//  SGWiFiUpload
//
//  Created by soulghost on 29/6/2016.
//  Copyright © 2016 soulghost. All rights reserved.
//

#import "SGConst.h"

NSString * const SGFileUploadDidStartNotification = @"SGFileUploadDidStartNotification";
NSString * const SGFileUploadProgressNotification = @"SGFileUploadProgressNotification";
NSString * const SGFileUploadDidEndNotification = @"SGFileUploadDidEndNotification";

