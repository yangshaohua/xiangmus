//
//  SGConst.h
//  SGWiFiUpload
//
//  Created by soulghost on 29/6/2016.
//  Copyright © 2016 soulghost. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString * const SGFileUploadDidStartNotification;
extern NSString * const SGFileUploadProgressNotification;
extern NSString * const SGFileUploadDidEndNotification;

