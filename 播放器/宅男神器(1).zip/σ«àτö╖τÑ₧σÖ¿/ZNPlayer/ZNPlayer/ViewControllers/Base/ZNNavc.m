//
//  ZNViewController.m
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/4.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import "ZNNavc.h"
#import "UIColor+Tools.h"
#import "UIBarButtonItem+Tools.h"

@interface ZNNavc () <UINavigationControllerDelegate,UIGestureRecognizerDelegate>

@end

@implementation ZNNavc

- (void)viewDidLoad {
    [super viewDidLoad];
    if ([self respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.interactivePopGestureRecognizer.delegate = self;
        self.delegate = self;
    }
    [self configure];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self configTitleTextAttributes];
}

#pragma mark - Override Method

- (NSArray *)popToRootViewControllerAnimated:(BOOL)animated {
    
    if([self respondsToSelector:@selector(interactivePopGestureRecognizer)]){
        
        self.interactivePopGestureRecognizer.enabled = NO;
    }
    
    return [super popToRootViewControllerAnimated:animated];
}

- (NSArray *)popToViewController:(UIViewController *)viewController animated:(BOOL)animated {
    
    if([self respondsToSelector:@selector(interactivePopGestureRecognizer)]){
        
        self.interactivePopGestureRecognizer.enabled = NO;
    }
    
    return [super popToViewController:viewController animated:animated];
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    [super pushViewController:viewController animated:animated];
    
    [self configLeftBarButton:viewController];
}

#pragma mark - Event

- (void)backButtonClicked {
    [self popViewControllerAnimated:YES];
}
#pragma mark - Logic Method

- (void)configure {
    // 1、设置透明导航栏和视图白色背景
    self.navigationBar.translucent = NO;
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)configTitleTextAttributes {
    
    UIFont *titleFont = [UIFont systemFontOfSize:17];
    UIColor *titleColor = [UIColor colorOfHex:0x666666];
    
    NSArray *objects = @[titleFont ,titleColor];
    NSArray *keys = @[NSFontAttributeName, NSForegroundColorAttributeName];
    
    NSDictionary *titleTextAttributes = [NSDictionary dictionaryWithObjects:objects forKeys:keys];
    self.navigationBar.titleTextAttributes = titleTextAttributes;
}

- (void)configLeftBarButton:(UIViewController *)curVC {
    if ([self needShowBackButton:curVC]) {
        curVC.navigationItem.leftBarButtonItem = [self buildBackButtonItemWithCurrentVC:curVC];
    }
}

#pragma mark UINavigationControllerDelegate

- (void)navigationController:(UINavigationController *)navigationController
       didShowViewController:(UIViewController *)viewController
                    animated:(BOOL)animate
{
    if ([self respondsToSelector:@selector(interactivePopGestureRecognizer)]){
        self.interactivePopGestureRecognizer.enabled = YES;
    }
}

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    
    //某些页面禁用手势 Dirt Code
    if ([self.topViewController isMemberOfClass:NSClassFromString(@"ZNXXViewController")]) {
        return NO;
    }
    
    if(gestureRecognizer == self.interactivePopGestureRecognizer){
        
        if(self.viewControllers.count < 2 || self.visibleViewController == self.viewControllers[0]){
            
            return NO;
        }
    }
    
    return YES;
}

#pragma mark - 左侧按钮展示相关逻辑元素

- (BOOL)needShowBackButton:(UIViewController *)vc {
    BOOL needShow = NO;
    NSUInteger curCount = self.viewControllers.count;
    // 非第一页，且没有返回按钮
    if (vc.navigationItem.leftBarButtonItem == nil && curCount > 1) {
        needShow = YES;
    }
    return needShow;
}

- (UIBarButtonItem *)buildBackButtonItemWithCurrentVC:(UIViewController *)currentVC {
    
    NSString *backImageName = @"sy_nav_back";
    UIBarButtonItem *backItem = nil;
    
    backItem = [UIBarButtonItem barItemWithNormalImage:backImageName hightImage:backImageName width:40 target:self action:@selector(backButtonClicked)];
    return backItem;
}

#pragma mark - Data builder

// 标题属性
- (NSDictionary *)fetchTitleAttributes {
    NSMutableDictionary *attributes = [NSMutableDictionary new];
    attributes[NSFontAttributeName] = [UIFont systemFontOfSize:18];
    attributes[NSForegroundColorAttributeName] = [UIColor colorOfHex:0x333333];
    return attributes;
}

@end
