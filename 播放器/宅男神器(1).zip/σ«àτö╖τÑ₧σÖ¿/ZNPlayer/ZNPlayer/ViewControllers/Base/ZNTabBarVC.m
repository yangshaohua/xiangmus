//
//  ZNTabBarVC.m
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/4.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import "ZNTabBarVC.h"

@interface ZNTabBarVC ()

@end

@implementation ZNTabBarVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (id)initWithSubViews:(NSArray *)subvcs
{
    self = [super init];
    if (self) {
        self.tabBar.translucent = NO;

        self.viewControllers = subvcs;
    }
    return self;
}



@end
