//
//  MyVideosVC.m
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/4.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import "ZNVideosVC.h"
#import "ZNVideosVC+ViewConfig.h"
#import "SGWiFiUploadManager.h"
#import "ZNVideosModel.h"
#import "KRVideoPlayerController.h"
#import "UIImage+Tools.h"
#import "ZNVideoCell.h"
#import <SVProgressHUD.h>
#import <GoogleMobileAds/GADBannerView.h>
#import "ADHeaders.h"

@interface ZNVideosVC () <UITableViewDelegate, UITableViewDataSource>

@property(nonatomic, strong) ZNVideosModel *videosModel;
@property (nonatomic, strong) KRVideoPlayerController *videoController;

@end

@implementation ZNVideosVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // 1.设置 Title
    self.title = @"本地视频";
    // 2.绑定事件
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    
    [self.refreshControl addTarget:self action:@selector(refreshStateChange:) forControlEvents:UIControlEventValueChanged];
    [(UIButton *)self.rightBarButtonItem.customView addTarget:self action:@selector(wifiTransportClicked:) forControlEvents:UIControlEventTouchUpInside];
    // 虚假请求，只为获取网络权限
    NSURL *ipURL = [NSURL URLWithString:@"http://ipof.in/txt"];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *ip = [NSString stringWithContentsOfURL:ipURL encoding:NSUTF8StringEncoding error:nil];
        NSLog(@"%@", ip);
    });
    
    [SVProgressHUD setDefaultStyle:SVProgressHUDStyleDark];
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
    
    GADRequest *request = [GADRequest request];
    request.testDevices = @[ kGADSimulatorID ];
    self.bannerView.adUnitID = kAD_Goole_VideosPage_BannerID;
    self.bannerView.rootViewController = self;
    [self.bannerView loadRequest:request];
    
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
   
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 下拉刷新更新事件

- (void)refreshStateChange:(UIRefreshControl *)control {
    [self.tableView reloadData];
    [control endRefreshing];
}

#pragma mark - Private

- (void)playVideoWithURL:(NSURL *)url
{
    if (!self.videoController) {
        CGFloat startY = 0;
        if ([UIScreen mainScreen].bounds.size.height == 812) {
            startY = 112;
        }
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        self.videoController = [[KRVideoPlayerController alloc] initWithFrame:CGRectMake(0, 0, width, width*(9.0/16.0))];
        __weak typeof(self)weakSelf = self;
        [self.videoController setDimissCompleteBlock:^{
            weakSelf.videoController = nil;
        }];
        [self.videoController showInWindow];
    }
    self.videoController.contentURL = url;
}

#pragma mark - 打开 wifi 传输页面

- (void)wifiTransportClicked:(UIButton *)btn {
    SGWiFiUploadManager *mgr = [SGWiFiUploadManager sharedManager];
    BOOL success = [mgr startHTTPServerAtPort:8080];
    if (success) {
        [mgr setFileUploadStartCallback:^(NSString *fileName, NSString *savePath) {
            NSLog(@"File %@ Upload Start", fileName);
            [SVProgressHUD showProgress:0 status:@"开始传输"];
        }];
        [mgr setFileUploadProgressCallback:^(NSString *fileName, NSString *savePath, CGFloat progress) {
            NSLog(@"File %@ on progress %f", fileName, progress);
            [SVProgressHUD showProgress:progress status:@"传输中"];
        }];
        [mgr setFileUploadFinishCallback:^(NSString *fileName, NSString *savePath) {
            NSLog(@"File Upload Finish %@ at %@", fileName, savePath);
            [SVProgressHUD showProgress:1 status:@"传输完毕"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [SVProgressHUD dismiss];
            });
            [self.videosModel addVideoWithName:fileName filePath:savePath];
            [self.tableView reloadData];
        }];
    }
    [mgr showWiFiPageFrontViewController:self dismiss:^{
        [mgr stopHTTPServer];
    }];
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString *filepath = [[self.videosModel getAllVideoInfos] objectAtIndex:indexPath.row].filePath;
    
    if (filepath) {
        NSURL *videoURL = [NSURL fileURLWithPath:filepath];
        [self playVideoWithURL:videoURL];
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.videosModel getAllVideoInfos].count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    ZNVideoCell *cell = [ZNVideoCell cellWithTableView:tableView];
    
    NSString *name = [[self.videosModel getAllVideoInfos] objectAtIndex:indexPath.row].name;
    UIImage *thumberImage = [UIImage getScreenShotImageFromVideoPath:[[self.videosModel getAllVideoInfos] objectAtIndex:indexPath.row].filePath];
    NSString *otherInfo = [[self.videosModel getAllVideoInfos] objectAtIndex:indexPath.row].otherInfo;
    
    [cell setName:name];
    [cell setDetailText:otherInfo];
    [cell setVideoImage:thumberImage];
    
    return cell;
}



// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}


// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [self.videosModel removeVideoByIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [tableView reloadData];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma marl - Video model

- (ZNVideosModel *)videosModel {
    if (!_videosModel) {
        _videosModel = [ZNVideosModel new];
    }
    return _videosModel;
}

@end
