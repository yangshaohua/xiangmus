//
//  ZNVideosVC+ViewConfig.m
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/4.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import "ZNVideosVC+ViewConfig.h"
#import "UIBarButtonItem+Tools.h"
#import <objc/runtime.h>
#import <GoogleMobileAds/GADBannerView.h>
#import "SystemMacro.h"
#import "UIView+Tools.h"

@implementation ZNVideosVC (ViewConfig)

- (void)loadView {
    [super loadView];
    [self setupRefresh];
    [self setupRightBarbutton];
    [self setBottomView];
}

/**
 *  集成下拉刷新
 */
- (void)setupRefresh {
    //1.添加刷新控件
    self.tableView = [UITableView new];
    self.tableView.frame = CGRectMake(0, 0, kScreenBoundWidth, kScreenBoundHeight - kTabbarSafeAeraHeight - 44 - 49 - 50 - 20 - kTabbarBottomSafeAeraHeight - 8);
    [self.view addSubview:self.tableView];
    self.refreshControl = [[UIRefreshControl alloc]init];
    [self.tableView addSubview:self.refreshControl];
}


- (void)viewDidLayoutSubviews {
//    [self.bannerView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.mas_equalTo(20);
//        make.right.mas_equalTo(-20);
//        make.height.mas_equalTo(50);
//        make.bottom.mas_equalTo(self.view.superview);
//    }];
}

- (void)setBottomView {
    self.bannerView = [[GADBannerView alloc] init];
    [self.view addSubview:self.bannerView];
    
    self.bannerView.backgroundColor = [UIColor whiteColor];
    self.bannerView.frame = CGRectMake(10, self.tableView.maxY, kScreenBoundWidth - 20, 50);
}



- (void)setupRightBarbutton {
    self.rightBarButtonItem = [UIBarButtonItem barItemWithNormalImage:@"wifi" hightImage:@"wifi" target:nil action:NULL];
    self.navigationItem.rightBarButtonItem = self.rightBarButtonItem;
}

#pragma mark - Property

- (UIBarButtonItem *)rightBarButtonItem {
    return objc_getAssociatedObject(self, @selector(rightBarButtonItem));
}

- (void)setRightBarButtonItem:(UIBarButtonItem *)rightBarButtonItem {
    objc_setAssociatedObject(self, @selector(rightBarButtonItem), rightBarButtonItem, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (GADBannerView *)bannerView {
    return objc_getAssociatedObject(self, @selector(bannerView));
}

- (void)setBannerView:(GADBannerView *)bannerView {
    objc_setAssociatedObject(self, @selector(bannerView), bannerView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UITableView *)tableView {
    return objc_getAssociatedObject(self, @selector(tableView));
}

- (void)setTableView:(UITableView *)tableView {
    objc_setAssociatedObject(self, @selector(tableView), tableView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UIRefreshControl *)refreshControl {
    return objc_getAssociatedObject(self, @selector(refreshControl));
}

- (void)setRefreshControl:(UIRefreshControl *)refreshControl {
    objc_setAssociatedObject(self, @selector(refreshControl), refreshControl, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

@end
