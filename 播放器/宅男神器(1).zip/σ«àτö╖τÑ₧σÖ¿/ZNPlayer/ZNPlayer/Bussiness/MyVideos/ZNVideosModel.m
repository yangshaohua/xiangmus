//
//  ZNVideosModel.m
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/4.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import "ZNVideosModel.h"
#import "UIImage+Tools.h"
#import <AVFoundation/AVFoundation.h>

@interface ZNVideoInfo : NSObject <ZNVideoInfoInterface, NSCoding>

@property (nonatomic, copy, nonatomic) NSString *name;
@property (nonatomic, copy, nonatomic) NSString *filePath;
@property (nonatomic, copy, nonatomic) NSString *otherInfo;

@end

@implementation ZNVideoInfo

//解档
- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if ([super init]) {
        self.name = [aDecoder decodeObjectForKey:@"name"];
        self.filePath = [aDecoder decodeObjectForKey:@"filePath"];
        self.otherInfo = [aDecoder decodeObjectForKey:@"otherInfo"];

    }
    
    return self;
}

//归档
- (void)encodeWithCoder:(NSCoder *)aCoder {
    [aCoder encodeObject:self.name forKey:@"name"];
    [aCoder encodeObject:self.filePath forKey:@"filePath"];
    [aCoder encodeObject:self.otherInfo forKey:@"otherInfo"];

}


@end

@interface ZNVideosModel()

@property (nonatomic, strong) NSMutableArray<id<ZNVideoInfoInterface>> *videos;

@end

@implementation ZNVideosModel

- (instancetype)init {
    if (self = [super init]) {
        NSString *file = [self videosInfoSaveFile];
        self.videos = [NSKeyedUnarchiver unarchiveObjectWithFile:file];
    }
    return self;
}

- (NSString *)videosInfoSaveFile {
    NSString *file = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject stringByAppendingPathComponent:@"videoinfo.data"];
    return file;
}

- (BOOL)filterVideoFiler:(NSString *)fileName {
    BOOL canPlay = NO;
    NSString *nFileName = [[fileName copy] lowercaseString];
    if ([nFileName rangeOfString:@".mp4"].length > 0 ||
        [nFileName rangeOfString:@".avi"].length > 0 ||
        [nFileName rangeOfString:@".mov"].length > 0 ) {
        canPlay = YES;
    }
    return canPlay;
}

- (void)removeVideoByIndex:(NSUInteger)index {
    
    if (index >= self.videos.count) {
        return;
    }
    id<ZNVideoInfoInterface> video = self.videos[index];
    
    [self.videos removeObject:video];
    NSString *filePath = video.filePath;
    [self deleteFileOnPath:filePath];
    
    [NSKeyedArchiver archiveRootObject:self.videos toFile:[self videosInfoSaveFile]];

}

- (void)deleteFileOnPath:(NSString *)filePath {
    if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        //如果存在就删除
        [[NSFileManager defaultManager] removeItemAtPath: filePath error:nil];
    }
}

- (void)addVideoWithName:(NSString *)name
                filePath:(NSString *)filePath {
    if (filePath && name ) {
        if (![self filterVideoFiler:filePath]) {
            [self deleteFileOnPath:filePath];
        }
        // 1、如果重复，则移除之前的信息
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name == %@", name];
        NSArray *filteredArray = [self.videos filteredArrayUsingPredicate:predicate];
        if (filteredArray.count > 0) {
            [self.videos removeObject:filteredArray[0]];
        }
        // 2、添加新的信息
        ZNVideoInfo *videoModel = [ZNVideoInfo new];
        videoModel.name = name;
        videoModel.filePath = filePath;
        // 文件大小
        NSDictionary *fileAttributes = [[NSFileManager defaultManager] attributesOfItemAtPath:filePath error:nil];
        unsigned long long length = [fileAttributes fileSize];
        float ff = length/1024.0/1024.0;
        
        // 视频时长
        AVURLAsset * asset = [AVURLAsset assetWithURL:[NSURL fileURLWithPath:filePath]];
        CMTime   time = [asset duration];
        int seconds = ceil(time.value/time.timescale);
        double hoursElapsed = floor(seconds / 3600.0);
        double minutesElapsed = floor(seconds / 60.0);
        double secondsElapsed = fmod(seconds, 60.0);
        NSString *timeElapsedString = [NSString stringWithFormat:@"%01.0f:%02.0f:%02.0f", hoursElapsed, minutesElapsed, secondsElapsed];
        
        videoModel.otherInfo = [NSString stringWithFormat:@"%.1fMB    %@",ff, timeElapsedString];
        [self.videos addObject:videoModel];
        // 3、存储到本地
        NSString *videoinfoFile = [self videosInfoSaveFile];
       [NSKeyedArchiver archiveRootObject:self.videos toFile:videoinfoFile];
    }
}

- (NSArray *)getAllVideoInfos {
    return self.videos;
}

- (NSMutableArray *)videos {
    if (!_videos) {
        _videos = [NSMutableArray new];
    }
    return _videos;
}

@end
