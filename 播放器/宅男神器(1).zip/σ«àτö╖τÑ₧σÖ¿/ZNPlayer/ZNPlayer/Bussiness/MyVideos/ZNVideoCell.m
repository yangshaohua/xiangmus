//
//  ZNVideoCell.m
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/4.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import "ZNVideoCell.h"
#import "UIView+Tools.h"
#import "UIColor+Tools.h"
#import "UIImageCategories.h"

@interface ZNVideoCell()

@property (nonatomic, strong) UIImageView *videoImgVoiew;
@property (nonatomic, strong) UILabel *nameLbl;
@property (nonatomic, strong) UILabel *detailLbl;

@end

@implementation ZNVideoCell

+ (instancetype)cellWithTableView:(UITableView *)tableView {
    static NSString *CellIdentifier = @"ZNVideoCellIndntifier";
    ZNVideoCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[ZNVideoCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        
    }
    return cell;
}

- (void)setName:(NSString *)name {
    self.nameLbl.text = name;
}

- (void)setVideoImage:(UIImage *)image {
    self.videoImgVoiew.image = [image resizedImage:self.videoImgVoiew.size interpolationQuality:kCGInterpolationDefault];
}

- (void)setDetailText:(NSString *)text {
    self.detailLbl.text = text;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self buildViews];
    }
    return self;
}

- (void)buildViews {
    self.videoImgVoiew = [UIImageView new];
    self.nameLbl = [UILabel new];
    self.detailLbl = [UILabel new];
    
    [self addSubview:self.videoImgVoiew];
    [self addSubview:self.nameLbl];
    [self addSubview:self.detailLbl];
    
    self.videoImgVoiew.frame = CGRectMake(10, 8, 90, 64);
    self.videoImgVoiew.contentMode = UIViewContentModeScaleAspectFit;
    
    self.nameLbl.font = [UIFont systemFontOfSize:15];
    self.nameLbl.textColor = [UIColor colorOfHex:0x333333];
    
    
    self.nameLbl.x = self.videoImgVoiew.maxX + 10;
    self.nameLbl.y = self.videoImgVoiew.y + 10;
    self.nameLbl.size = CGSizeMake(200, 16);
    
    self.detailLbl.x = self.nameLbl.x;
    self.detailLbl.y = self.nameLbl.maxY + 15;
    
    self.detailLbl.size = CGSizeMake(200, 13);
    self.detailLbl.textColor = [UIColor colorOfHex:0x999999];
    self.detailLbl.font = [UIFont systemFontOfSize:13];
}


@end
