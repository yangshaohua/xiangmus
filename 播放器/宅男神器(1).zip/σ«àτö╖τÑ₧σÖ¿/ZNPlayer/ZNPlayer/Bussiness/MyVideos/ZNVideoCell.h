//
//  ZNVideoCell.h
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/4.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZNVideoCell : UITableViewCell

+ (instancetype)cellWithTableView:(UITableView *)tableView;

- (void)setName:(NSString *)name;
- (void)setVideoImage:(UIImage *)image;
- (void)setDetailText:(NSString *)text;

@end
