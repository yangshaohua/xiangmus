//
//  ZNVideosModel.h
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/4.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ZNVideoInfoInterface

@property (nonatomic, copy, nonatomic) NSString *name;
@property (nonatomic, copy, nonatomic) NSString *filePath;
@property (nonatomic, copy, nonatomic) NSString *otherInfo;

@end



@interface ZNVideosModel : NSObject

- (void)addVideoWithName:(NSString *)name
                filePath:(NSString *)filePath;

- (void)removeVideoByIndex:(NSUInteger)index;
- (NSArray<id<ZNVideoInfoInterface>> *)getAllVideoInfos;

@end
