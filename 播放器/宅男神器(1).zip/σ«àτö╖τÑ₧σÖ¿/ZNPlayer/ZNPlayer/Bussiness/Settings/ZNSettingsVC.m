//
//  ZNSettingsVC.m
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/4.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import "ZNSettingsVC.h"
#import "UIColor+Tools.h"
@import GoogleMobileAds;
#import "UIView+Tools.h"
#import <Masonry.h>
#import "ADHeaders.h"

#define VERSIONID [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]

@interface SYAboutTextView : UIView

@property (nonatomic, strong) UILabel *label;
@property (nonatomic, strong) UILabel *notesLabel;
@property (nonatomic, strong) UIImageView *rightImageView;


@end

@implementation SYAboutTextView

@synthesize label, notesLabel, rightImageView;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor whiteColor];
        [self ViewDidLoad];
    }
    return self;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

- (void)ViewDidLoad
{
    label = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, self.frame.size.width - 190, 50)];
    label.textAlignment = NSTextAlignmentLeft;
    label.textColor = [UIColor colorOfHex:0x666666];
    [label setFont:[UIFont boldSystemFontOfSize:15]];
    
    label.backgroundColor = [UIColor clearColor];
    [self addSubview:label];
    
    notesLabel =
    [[UILabel alloc] initWithFrame:CGRectMake(label.frame.origin.x + label.frame.size.width + 25, 0, 120, 50)];
    notesLabel.textAlignment = NSTextAlignmentRight;
    notesLabel.textColor = [UIColor colorOfHex:0x999999];
    [notesLabel setFont:[UIFont systemFontOfSize:15]];
    notesLabel.backgroundColor = [UIColor clearColor];
    [self addSubview:notesLabel];
    
    rightImageView = [[UIImageView alloc]
                      initWithFrame:CGRectMake(notesLabel.frame.origin.x + notesLabel.frame.size.width + 5, 15, 10.5, 18)];
    [rightImageView setImage:[UIImage imageNamed:@"RightArrow"]];
    [self addSubview:rightImageView];
    
    UIView *lineView =
    [[UIView alloc] initWithFrame:CGRectMake(0, self.frame.size.height - 0.5, self.frame.size.width - 15, 0.5)];
    lineView.backgroundColor = [UIColor colorOfHex:0xe0e0e0];
    [self addSubview:lineView];
    
   
}

@end

@interface ZNSettingsVC ()
@property (nonatomic, strong) GADBannerView *bannerView;

@end

@implementation ZNSettingsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"设置";
    self.view.backgroundColor = [UIColor colorOfHex:0xf5f5f5];
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Icon-180px"]];
    imageView.frame = CGRectMake(([UIScreen mainScreen].bounds.size.width - 100) / 2, 100, 100, 100);
    [self.view addSubview:imageView];
    
    UILabel *versionLabel =
    [[UILabel alloc] initWithFrame:CGRectMake(0, imageView.frame.origin.y + imageView.frame.size.height + 10,
                                              self.view.frame.size.width, 30)];
    versionLabel.backgroundColor = [UIColor clearColor];
    versionLabel.textAlignment = NSTextAlignmentCenter;
    versionLabel.textColor = [UIColor colorOfHex:0x999999];
    [versionLabel setFont:[UIFont systemFontOfSize:20]];
    versionLabel.text = [NSString stringWithFormat:@"宅男神器 V%@", VERSIONID];
    [self.view addSubview:versionLabel];
    
    SYAboutTextView *weixin = [[SYAboutTextView alloc]
                               initWithFrame:CGRectMake(0, versionLabel.frame.origin.y + versionLabel.frame.size.height + 30,
                                                        self.view.frame.size.width, 50)];
    weixin.notesLabel.frame = CGRectMake(self.view.width - 130, 0, 120, 50);
    weixin.label.text = @"微信公众号";
    weixin.notesLabel.text = @"@宅男娱乐";
    weixin.rightImageView.frame = CGRectMake(0, 0, 0, 0);
    [self.view addSubview:weixin];
    
    UIView *wLineView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, weixin.frame.size.width, 1 / [UIScreen mainScreen].scale)];
    wLineView.backgroundColor = [UIColor colorOfHex:0xd6d6d6];
    [weixin addSubview:wLineView];
    
    SYAboutTextView *xinlang = [[SYAboutTextView alloc]
                                initWithFrame:CGRectMake(0, weixin.frame.origin.y + weixin.frame.size.height, self.view.frame.size.width, 50)];
    xinlang.label.frame = CGRectMake(15, 0, 150, 50);
    xinlang.notesLabel.frame = CGRectMake(self.view.width - 130, 0, 120, 50);
    xinlang.label.text = @"评分后，更精彩";
    xinlang.label.textColor = [UIColor colorOfHex:0xe6454a];
    xinlang.notesLabel.text = @"@AppStore";
    xinlang.notesLabel.textAlignment = NSTextAlignmentRight;
    xinlang.rightImageView.frame = CGRectMake(0, 0, 0, 0);
    [self.view addSubview:xinlang];
    
    xinlang.userInteractionEnabled = YES;
    
    [xinlang addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap)]];
    
    // 底部广告
    [self.view addSubview:self.bannerView];
    self.bannerView.backgroundColor = [UIColor whiteColor];
    [self.bannerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(50);
        make.left.mas_equalTo(20);
        make.right.mas_equalTo(-20);
        make.bottom.mas_equalTo(self.view);
    }];
    self.bannerView.adUnitID = kAD_Goole_SettingPage_BannerID;
    self.bannerView.rootViewController = self;
    GADRequest *request = [GADRequest request];
    // kGADSimulatorID @"cbbb99ceec80109c98c2a5e836dd21fd"
    request.testDevices = @[ kGADSimulatorID ];
    
    [self.bannerView loadRequest:request];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
}

- (GADBannerView *)bannerView {
    if (!_bannerView) {
        _bannerView = [[GADBannerView alloc] init];
    }
    return _bannerView;
}

- (void)tap {
    // 跳 AppStore 页
}

@end
