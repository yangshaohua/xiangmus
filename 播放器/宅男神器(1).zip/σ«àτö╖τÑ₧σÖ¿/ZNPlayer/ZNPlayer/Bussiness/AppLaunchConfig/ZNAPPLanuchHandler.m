//
//  ZNAPPLanuchHandler.m
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/4.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import "ZNAPPLanuchHandler.h"
// Base
#import "ZNNavc.h"
#import "ZNTabBarVC.h"
// Tools
#import "UIViewController+Config.h"
// Pages
#import "ZNVideosVC.h"
#import "ZNWebBrowserVC.h"
#import "ZNSettingsVC.h"

@implementation ZNAPPLanuchHandler

+ (UIViewController *)rootVC {
    ZNTabBarVC *tabberViewController = [[ZNTabBarVC alloc] initWithSubViews:[self configVCS]];
    //ZNNavc *navc = [[ZNNavc alloc] initWithRootViewController:tabberViewController];
    return tabberViewController;
}

+ (NSArray *)configVCS {
    ZNVideosVC *videosVC = [ZNVideosVC new];
    //ZNWebBrowserVC *browserVC = [ZNWebBrowserVC new];
    ZNSettingsVC *settingsVC = [ZNSettingsVC new];
    
    [videosVC configVCTabBarTitleWithTitle:@"我的视频" normalImage:@"my_videos" selectImage:@"my_videos_highlighted"];
//    [browserVC configVCTabBarTitleWithTitle:@"打开网址" normalImage:@"my_videos" selectImage:@"my_videos_highlighted"];
    [settingsVC configVCTabBarTitleWithTitle:@"设置" normalImage:@"settings" selectImage:@"settings_highlighted"];

    
    return @[[[ZNNavc alloc] initWithRootViewController:videosVC], [[ZNNavc alloc] initWithRootViewController:settingsVC]];
}

@end
