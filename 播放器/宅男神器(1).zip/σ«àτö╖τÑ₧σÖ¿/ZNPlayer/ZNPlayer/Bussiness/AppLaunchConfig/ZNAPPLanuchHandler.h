//
//  ZNAPPLanuchHandler.h
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/4.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZNAPPLanuchHandler : NSObject
+ (UIViewController *)rootVC;
@end
