//
//  UIViewController+Config.m
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/4.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import "UIViewController+Config.h"
#import "UIColor+Tools.h"

@implementation UIViewController (Config)

- (void)configVCTabBarTitleWithTitle:(NSString *)title
                         normalImage:(NSString *)normalImage
                         selectImage:(NSString *)selectImag {
    self.tabBarItem.title = title;
    [self.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                           [UIColor colorOfHex:0x888888], NSForegroundColorAttributeName,
                                           [UIFont systemFontOfSize:12], NSFontAttributeName,
                                           nil] forState:UIControlStateNormal]  ;
    [self.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                           [UIColor colorOfHex:0xE6454A], NSForegroundColorAttributeName,
                                           [UIFont boldSystemFontOfSize:12], NSFontAttributeName,
                                           nil] forState:UIControlStateSelected]  ;
    UIOffset offset = self.tabBarItem.titlePositionAdjustment ;
    offset.vertical -= 0;
    self.tabBarItem.titlePositionAdjustment = offset ;
    self.tabBarItem.image = [[UIImage imageNamed:normalImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    self.tabBarItem.selectedImage = [[UIImage imageNamed:selectImag] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
}

@end
