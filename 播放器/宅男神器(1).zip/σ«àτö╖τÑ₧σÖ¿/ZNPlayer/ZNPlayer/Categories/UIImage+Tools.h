//
//  UIImage+Tools.h
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/4.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Tools)
/**
 *  获取视频的缩略图方法
 *
 *  @param filePath 视频的本地路径
 *
 *  @return 视频截图
 */
+ (UIImage *)getScreenShotImageFromVideoPath:(NSString *)filePath;

- (UIImage*)scaleToSize:(CGSize)size;

@end
