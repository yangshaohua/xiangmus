//
//  UIBarButtonItem+Tools.m
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/4.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import "UIBarButtonItem+Tools.h"

@implementation UIBarButtonItem (Tools)

+ (UIBarButtonItem *)barItemWithNormalImage:(NSString *)normalImageName
                                 hightImage:(NSString *)highlightImageName
                                     target:(id)target
                                     action:(SEL)action
{
    UIButton *itemButton = [UIButton buttonWithType:UIButtonTypeCustom];
    UIImage *image = [UIImage imageNamed:normalImageName];
    itemButton.frame = CGRectMake(0, 0, image.size.width + 10, image.size.height + 10);
    itemButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [itemButton setImage:image forState:UIControlStateNormal];
    [itemButton setImage:[UIImage imageNamed:highlightImageName] forState:UIControlStateHighlighted];
    [itemButton addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
    return [[UIBarButtonItem alloc] initWithCustomView:itemButton];
}

+ (UIBarButtonItem *)barItemWithNormalImage:(NSString *)normalImageName
                                 hightImage:(NSString *)highlightImageName
                                      width:(CGFloat)width
                                     target:(id)target
                                     action:(SEL)action {
    
    UIButton *itemButton = [UIButton buttonWithType:UIButtonTypeCustom];
    UIImage *image = [UIImage imageNamed:normalImageName];
    itemButton.frame = CGRectMake(0, 0, width, 44);
    itemButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [itemButton setImage:image forState:UIControlStateNormal];
    [itemButton setImage:[UIImage imageNamed:highlightImageName] forState:UIControlStateHighlighted];
    [itemButton addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    return [[UIBarButtonItem alloc] initWithCustomView:itemButton];
}

@end
