//
//  UIBarButtonItem+Tools.h
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/4.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (Tools)

+ (UIBarButtonItem *)barItemWithNormalImage:(NSString *)normalImageName
                                 hightImage:(NSString *)highlightImageName
                                     target:(id)target
                                     action:(SEL)action;

+ (UIBarButtonItem *)barItemWithNormalImage:(NSString *)normalImageName
                                 hightImage:(NSString *)highlightImageName
                                      width:(CGFloat)width
                                     target:(id)target
                                     action:(SEL)action;

@end
