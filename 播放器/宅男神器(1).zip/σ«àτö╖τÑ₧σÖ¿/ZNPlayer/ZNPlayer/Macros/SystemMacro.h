//
//  SystemMacro.h
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/7.
//  Copyright © 2018年 lisz. All rights reserved.
//

#ifndef SystemMacro_h
#define SystemMacro_h

#define IS_IPHONEX      kScreenBoundHeight == 812
#define kSkin_Color  ColorOfHex(0xFA5856)

#define kScreenSize         ([UIScreen mainScreen].bounds.size)

#define kTabbarSafeAeraHeight (IS_IPHONEX ? 34 : 0)
#define kScreenBoundHeight  ([UIScreen mainScreen].bounds.size.height)
#define kScreenBoundWidth  ([UIScreen mainScreen].bounds.size.width)
#define kTabbarBottomSafeAeraHeight (IS_IPHONEX ? 17 : 0)

#endif /* SystemMacro_h */
