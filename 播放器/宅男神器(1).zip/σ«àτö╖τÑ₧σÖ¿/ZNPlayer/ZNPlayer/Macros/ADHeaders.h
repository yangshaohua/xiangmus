//
//  ADHeaders.h
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/7.
//  Copyright © 2018年 lisz. All rights reserved.
//

#ifndef ADHeaders_h
#define ADHeaders_h

#define AD_SETTINGS    1


#if AD_SETTINGS == 1

/* ========= Start ========= */

// 1、谷歌广告 id
#define kAD_Goole_APPID @"ca-app-pub-9504668977122385~6057892452"
// 2、启动后的弹屏广告
#define kAD_Goole_AfterLaunching_ID @"ca-app-pub-9504668977122385/7583916482"
// 3、设置页横屏广告
#define kAD_Goole_SettingPage_BannerID @"ca-app-pub-9504668977122385/6327154061"
// 4、视频页横屏广告
#define kAD_Goole_VideosPage_BannerID @"ca-app-pub-9504668977122385/3234086863"

/* ========= End ========= */

#elif AD_SETTINGS == 2

// 1、谷歌广告 id
#define kAD_Goole_APPID @"ca-app-pub-3940256099942544~1458002511"
// 2、启动后的弹屏广告
#define kAD_Goole_AfterLaunching_ID @"ca-app-pub-9504668977122385/7583916482"
// 3、设置页横屏广告
#define kAD_Goole_SettingPage_BannerID @"ca-app-pub-4ew/2934735716"

/* ========= End ========= */
#endif

#endif /* ADHeaders_h */
