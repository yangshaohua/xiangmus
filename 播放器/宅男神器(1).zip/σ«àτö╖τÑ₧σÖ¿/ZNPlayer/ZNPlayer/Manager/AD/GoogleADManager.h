//
//  GoogleADManager.h
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/7.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import <Foundation/Foundation.h>

@class GADInterstitial;

@interface GoogleADManager : NSObject
@property(nonatomic, strong) GADInterstitial *interstitial;
+ (instancetype)sharedInstance;

- (void)showADWithDurition:(NSInteger)durition adID:(NSString *)adID;

@end
