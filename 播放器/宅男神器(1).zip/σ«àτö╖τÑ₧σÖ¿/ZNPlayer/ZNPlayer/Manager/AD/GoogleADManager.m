//
//  GoogleADManager.m
//  ZNPlayer
//
//  Created by shaozhou li on 2018/3/7.
//  Copyright © 2018年 lisz. All rights reserved.
//

#import "GoogleADManager.h"
@import GoogleMobileAds;
#import "UIColor+Tools.h"
#import "SystemMacro.h"

@interface GoogleADManager ()<GADInterstitialDelegate>
{
    NSInteger _showDurition;
    
    NSTimer *_timer;
    
    UIButton *_closeButton;
    
    UIView   *_screenView;
    NSString *adid;
}
@end

@implementation GoogleADManager
+ (instancetype)sharedInstance
{
    static GoogleADManager *mediator;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        mediator = [[GoogleADManager alloc] init];
    });
    return mediator;
}

- (void)showADWithDurition:(NSInteger)durition adID:(NSString *)adID {
    _showDurition = durition + 1;
    adid = adID;
    [self createAndLoadInterstitial];
    
}

- (void)createAndLoadInterstitial
{
    self.interstitial =
    [[GADInterstitial alloc] initWithAdUnitID:adid];
    
    GADRequest *request = [GADRequest request];
    // Request test ads on devices you specify. Your test device ID is printed to the console when
    // an ad request is made.  cbbb99ceec80109c98c2a5e836dd21fd kGADSimulatorID
    request.testDevices = @[ kGADSimulatorID ];
    self.interstitial.delegate = self;
    [self.interstitial loadRequest:request];
}

- (void)interstitialDidReceiveAd:(GADInterstitial *)ad
{
    [_screenView removeFromSuperview];
    [self show];
}

- (void)show
{
    if (self.interstitial.isReady) {
        [self.interstitial presentFromRootViewController:((UINavigationController *)[UIApplication sharedApplication].delegate.window.rootViewController)];
        
        [self.interstitialController.view addSubview:[self closeButton]];
        [_closeButton setTitle:[NSString stringWithFormat:@"跳过%ld", (long)_showDurition] forState:UIControlStateNormal];
        
        if (_timer) {
            [_timer invalidate];
        }
        _timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timeReduce) userInfo:nil repeats:YES];
        
        
    } else {
        NSLog(@"Ad wasn't ready");
    }
}

- (UIButton *)closeButton
{
    if (!_closeButton) {
        _closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _closeButton.frame = CGRectMake(kScreenSize.width - 90, 10 + kTabbarSafeAeraHeight, 80, 35);
        _closeButton.backgroundColor = [UIColor colorOfHex:0xFA5856];
        _closeButton.layer.cornerRadius = 35/2.0;
        _closeButton.tag = 100;
        _closeButton.layer.masksToBounds = YES;
        _closeButton.layer.borderColor = [UIColor whiteColor].CGColor;
        _closeButton.layer.borderWidth = 1;
        [_closeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_closeButton addTarget:self action:@selector(closeClick) forControlEvents:UIControlEventTouchUpInside];
    }
    return _closeButton;
}

- (void)timeReduce
{
    _showDurition--;
    
    if (_showDurition < 0) {
        [_timer invalidate];
        _timer = nil;
        [self.interstitialController dismissViewControllerAnimated:YES completion:^{
            
        }];
    }
    [self.interstitialController.view bringSubviewToFront:_closeButton];
    [_closeButton setTitle:[NSString stringWithFormat:@"跳过%ld", (long)_showDurition] forState:UIControlStateNormal];
}

- (void)closeClick
{
    [self.interstitialController dismissViewControllerAnimated:YES completion:^{
        
    }];
}

- (UIViewController *)interstitialController
{
    UIViewController * vc = nil;
    if ([self.interstitial respondsToSelector:@selector(viewController)]) {
        vc = [self.interstitial performSelector:@selector(viewController) withObject:nil];
    }
    return vc;
}
@end
