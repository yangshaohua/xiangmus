
//
//  PayModel.m
//  MortgageCalculator
//
//  Created by yangshaohua on 2017/12/10.
//  Copyright © 2017年 yangshaohua. All rights reserved.
//

#import "PayModel.h"

@implementation PayModel

@end
