//
//  CalculatorResultModel.m
//  MortgageCalculator
//
//  Created by yangshaohua on 2017/12/12.
//  Copyright © 2017年 yangshaohua. All rights reserved.
//

#import "CalculatorResultModel.h"
#import "PayModel.h"
@implementation CalculatorResultModel

@end
