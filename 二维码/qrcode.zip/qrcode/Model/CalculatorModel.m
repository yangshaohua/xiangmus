//
//  CalculatorModel.m
//  MortgageCalculator
//
//  Created by yangshaohua on 2017/12/8.
//  Copyright © 2017年 yangshaohua. All rights reserved.
//

#import "CalculatorModel.h"
@implementation ValueModel

@end

@implementation CalculatorModel

@end
