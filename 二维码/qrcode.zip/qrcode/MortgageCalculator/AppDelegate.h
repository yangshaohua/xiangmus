//
//  AppDelegate.h
//  MortgageCalculator
//
//  Created by yangshaohua on 2017/12/7.
//  Copyright © 2017年 yangshaohua. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end



/*
 f5 cd 48
 */

/*
 http://confluence.daojia-inc.com/pages/viewpage.action?pageId=51780250
 后台系统
 chenjiaojiao.    gaoyun
 
 企业APPID
 58SuYun.SuYunDriverEnterprise
 
 
 
 pickview  提前还贷
 
 利率变更 
 顶部数据变更
 
 
 */
