//
//  UITabBar+badge.h
//  SuYunDriver
//
//  Created by 于洪志 on 2017/9/22.
//  Copyright © 2017年 58SuYun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITabBar (badge)



- (UIView *)showBadgeOnItmIndex:(NSInteger)index withItemsCount:(NSInteger)count;

@end
