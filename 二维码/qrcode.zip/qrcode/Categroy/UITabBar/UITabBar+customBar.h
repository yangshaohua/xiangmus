//
//  UITabBar+customBar.h
//  SuYunDriver
//
//  Created by 张佳炫 on 2017/8/31.
//  Copyright © 2017年 58SuYun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface UITabBar (customBar)

- (void)ul_setUpLineColor:(UIColor *)color;

@end
