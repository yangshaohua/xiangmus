//
//  ThirdPartHeader.h
//  MortgageCalculator
//
//  Created by yangshaohua on 2017/12/7.
//  Copyright © 2017年 yangshaohua. All rights reserved.
//

#ifndef ThirdPartHeader_h
#define ThirdPartHeader_h

//bugly 信息
#define kBugly_AppId         @"b8ec890176"

//#ifdef DEBUG
////admob信息
//#define kADMob_AppId         @""//appid
//
//#define kADMob_HomeUnitId    @""//首页单元
//
//#define kADMob_ResultUnitId    @""//计算详情页单元
//
//#define kADMob_StartUnitId    @""//开机弹屏
//#else
//admob信息
#define kADMob_AppId         @"ca-app-pub-9491980216612560~9629395867"//appid

#define kADMob_HomeUnitId    @"ca-app-pub-9491980216612560/2605471561"//首页单元

#define kADMob_ResultUnitId    @"ca-app-pub-9491980216612560/9402814200"//详情页单元

//#endif




#define kADMobHeight         50.0


#endif /* ThirdPartHeader_h */
