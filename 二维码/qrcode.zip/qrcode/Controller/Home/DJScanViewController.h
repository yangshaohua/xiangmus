//
//  DJScanViewController.h
//  Jiazheng
//
//  Created by liuy on 2017/9/18.
//  Copyright © 2017年 58. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DJScanViewController : UIViewController

@end
