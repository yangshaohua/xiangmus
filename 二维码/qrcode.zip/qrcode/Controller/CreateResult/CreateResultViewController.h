//
//  CreateResultViewController.h
//  MortgageCalculator
//
//  Created by yangshaohua on 2018/1/14.
//  Copyright © 2018年 yangshaohua. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreateResultViewController : UIViewController
@property (copy, nonatomic) NSString *result;
@end
