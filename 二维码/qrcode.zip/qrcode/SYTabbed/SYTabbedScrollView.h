//
//  SYTabbedScrollView.h
//  SuYun
//
//  Created by 郭杨 on 15/11/30.
//  Copyright © 2015年 58. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SYTabbedScrollView : UIScrollView

@end
